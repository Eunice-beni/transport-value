-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mer. 31 août 2022 à 07:06
-- Version du serveur : 8.0.27
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `valuet`
--

-- --------------------------------------------------------

--
-- Structure de la table `donnees_itineraire`
--

DROP TABLE IF EXISTS `donnees_itineraire`;
CREATE TABLE IF NOT EXISTS `donnees_itineraire` (
  `id` int NOT NULL AUTO_INCREMENT,
  `jour` int NOT NULL,
  `moyen` int NOT NULL,
  `trajet` int NOT NULL,
  `heure` int NOT NULL,
  `prix_eco` int DEFAULT NULL,
  `prix_confort` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Structure de la table `horaire`
--

DROP TABLE IF EXISTS `horaire`;
CREATE TABLE IF NOT EXISTS `horaire` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tranche` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `horaire`
--

INSERT INTO `horaire` (`id`, `tranche`) VALUES
(1, '00h - 01h'),
(2, '01h - 02h'),
(3, '02h - 03h'),
(4, '03h - 04h'),
(5, '04h - 05h'),
(6, '05h - 06h'),
(7, '06h - 07h'),
(8, '07h - 08h'),
(9, '08h - 09h'),
(10, '09h - 10h'),
(11, '10h - 11h'),
(12, '11h - 12h'),
(13, '12h - 13h'),
(14, '13h - 14h'),
(15, '14h - 15h'),
(16, '15h - 16h'),
(17, '16h - 17h'),
(18, '17h - 18h'),
(19, '18h - 19h'),
(20, '19h - 20h'),
(21, '20h - 21h'),
(22, '21h - 22h'),
(23, '22h - 23h'),
(24, '23h - 00h');

-- --------------------------------------------------------

--
-- Structure de la table `itineraire`
--

DROP TABLE IF EXISTS `itineraire`;
CREATE TABLE IF NOT EXISTS `itineraire` (
  `id` int NOT NULL AUTO_INCREMENT,
  `trajet` varchar(255) NOT NULL,
  `distance` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `itineraire`
--

INSERT INTO `itineraire` (`id`, `trajet`, `distance`) VALUES
(1, 'Yopougon Saint-André - Cité Administrative Plateau ', 13),
(2, 'Hôtel du Golf - Cap Nord Riviera', 6),
(3, 'Carrefour de la Vie - Carrefour Faya', 8);

-- --------------------------------------------------------

--
-- Structure de la table `jour`
--

DROP TABLE IF EXISTS `jour`;
CREATE TABLE IF NOT EXISTS `jour` (
  `id` int NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `jour`
--

INSERT INTO `jour` (`id`, `libelle`) VALUES
(1, 'Lundi'),
(2, 'Mardi'),
(3, 'Mercredi'),
(4, 'Jeudi'),
(5, 'Vendredi'),
(6, 'Samedi'),
(7, 'Dimanche');

-- --------------------------------------------------------

--
-- Structure de la table `moyen`
--

DROP TABLE IF EXISTS `moyen`;
CREATE TABLE IF NOT EXISTS `moyen` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `moyen`
--

INSERT INTO `moyen` (`id`, `nom`) VALUES
(1, 'Yango'),
(2, 'Uber'),
(3, 'Heetch');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
