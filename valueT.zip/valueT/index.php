<?php

    // inclus connexion.php
    include ("connexion.php");  
    
    // recuperation des JOURS 
    $jour = $conn->prepare("SELECT id, libelle FROM jour ORDER BY id ASC");
    $jour->execute();
    $jour->setFetchMode(PDO::FETCH_ASSOC);
    $jours = $jour->fetchAll(); 

    // recuperation de la liste des moyens des TRANSPORT 
    $moyen = $conn->prepare("SELECT id, nom FROM moyen ORDER BY nom ASC");
    $moyen->execute();
    $moyen->setFetchMode(PDO::FETCH_ASSOC);
    $moyens = $moyen->fetchAll();
	
    // recuperation de la liste des ITINERAIRE 
    $trajet = $conn->prepare("SELECT id, trajet, distance FROM itineraire ORDER BY id ASC");
    $trajet->execute();
    $trajet->setFetchMode(PDO::FETCH_ASSOC);
    $trajets = $trajet->fetchAll();

    // recuperation de la liste des tranches d'HEURES
    $heure = $conn->prepare("SELECT id, tranche FROM horaire ORDER BY id ASC");
    $heure->execute();
    $heure->setFetchMode(PDO::FETCH_ASSOC);
    $heures = $heure->fetchAll();

    // Envoie des donnees dans la base de donnee
    if (isset($_POST["enregistrer"])) {
        
	$jour = $_POST["jour"];
	$moyen = $_POST["moyen"];
        $trajet = $_POST["trajet"];
	$heure = $_POST["heure"];
        $prix_eco = $_POST["prix_eco"];
	$prix_confort = $_POST["prix_confort"];

        $stmt = $conn->prepare("INSERT INTO donnees_itineraire (jour, moyen, trajet, heure, prix_eco, prix_confort) VALUES (:jour, :moyen, :trajet, :heure, :prix_eco, :prix_confort)");
	$stmt->bindParam(':jour', $jour);
        $stmt->bindParam(':moyen', $moyen);
        $stmt->bindParam(':trajet', $trajet);
        $stmt->bindParam(':heure', $heure);
	$stmt->bindParam(':prix_eco', $prix_eco);
	$stmt->bindParam(':prix_confort', $prix_confort);

        $stmt->execute();
	
    }

    
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Enregistrment des donnees</title>
    <style>
            /* style global */
            body{
                background: fdfdfd;
		overflow: hidden;
                font-size: 22px;
                margin: 0px;
                padding: 0px;
            }

            #container{
                width: 400px;
                margin: 0 auto;
                margin-top: 5%;
            }

            h1 {
                text-align: center;
            }

            /* Bordered form */
            form {
                width:100%;
                padding: 30px;
                border: 1px solid #f1f1f1;
                background: #fff;
                box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
            }

            #container h1{
                width: 38%;
                margin: 0 auto;
                padding-bottom: 10px;
            }

            /* Full-width inputs */
            input[type=text],input[type=number], select {
                width: 100%;
                padding: 12px 20px;
                margin: 8px 0;
                display: inline-block;
                border: 1px solid #ccc;
                box-sizing: border-box;
            }

            /* Set a style for all buttons */
            input[type=submit] {
                background-color: #53af57;
                color: white;
                padding: 14px 20px;
                margin: 8px 0;
                border: 1px solid #53af57;
                cursor: pointer;
                width: 100%;
            }

            input[type=submit]:hover {
                background-color: white;
                color: #53af57;
                border: 1px solid #53af57;
            }

            /* header & footer style */
            header{
                display: flex;
                justify-content: center;
                align-items: center;
                background: #53af57;
                color: white;
                position: relative;
                top: 0px;
                height: 100px;
                width: 100%;
            }

            footer{
                text-align: center;
                background: black;
                position: absolute;
                bottom: 0px;
                height: 50px;
                width: 100%;
                color: white;
            }
        </style>
</head>

<body>
    
    <header>
        <h1>Recensement</h1>
    </header>

    <main id="container">
        <form action="index.php" method="POST">
	    <div>
                <select name="jour">
                    <option>Choisir le jour </option>
                    <?php foreach ($jours as $jour) { ?>
                        <option value=<?php echo $jour['id'] ?> ><?php echo $jour['libelle']; ?> </option>
                    <?php } ?>
                </select>
            </div>         
            <div>
                <select name="moyen">
                    <option>Choisir un moyen de transport</option>
                    <?php foreach ($moyens as $moyen) { ?>
                        <option value=<?php echo $moyen['id'] ?> ><?php echo $moyen['nom']; ?> </option>
                    <?php } ?>
                </select>
            </div>
	    <div>
                <select name="trajet">
                    <option>Choisir un itineraire</option>
                    <?php foreach ($trajets as $trajet) { ?>
                        <option value=<?php echo $trajet['id'] ?> ><?php echo $trajet['trajet']; ?> </option>
                    <?php } ?>
                </select>
            </div>
	    <div>
                <select name="heure">
                    <option>Choisir une tranche d'heure</option>
                    <?php foreach ($heures as $heure) { ?>
                        <option value=<?php echo $heure['id'] ?> ><?php echo $heure['tranche']; ?> </option>
                    <?php } ?>
                </select>
            </div>
	    <div>
		<label>Entrer le prix Eco</label>
                <input type="number" name="prix_eco" value="" min="0" required>
            </div>
	    <div>
		<label>Entrer le prix Confort</label>
                <input type="number" name="prix_confort" value="" min="0">
            </div>
            <div>
                <input type="submit" name="enregistrer" value="Enregistrer">
            </div>
        </form>
    </main>

    <footer>
        <marquee><p>&copy; Copyright 2022 - Tous droits reserves</p></marquee>
    </footer>
</body>

</html>